import 'package:permission_handler/permission_handler.dart';

class PermissionsService {
  Future<bool> requestMicrophone() async {
    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  Future<bool> requestCamera() async {
    final status = await Permission.camera.request();
    return status.isGranted;
  }

  Future<bool> checkMicrophone() async {
    return await Permission.microphone.isGranted;
  }
}
