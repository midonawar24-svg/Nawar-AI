/// Models for SQLite - المرحلة 2: قاعدة بيانات حقيقية بدل SharedPreferences

class ConversationModel {
  final int? id;
  final String input;
  final String output;
  final String intent;
  final String command;
  final double confidence;
  final bool success;
  final DateTime timestamp;

  ConversationModel({
    this.id,
    required this.input,
    required this.output,
    required this.intent,
    required this.command,
    required this.confidence,
    required this.success,
    required this.timestamp,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'input': input,
    'output': output,
    'intent': intent,
    'command': command,
    'confidence': confidence,
    'success': success ? 1 : 0,
    'timestamp': timestamp.millisecondsSinceEpoch,
  };

  factory ConversationModel.fromMap(Map<String, dynamic> map) => ConversationModel(
    id: map['id'],
    input: map['input'],
    output: map['output'],
    intent: map['intent'],
    command: map['command'],
    confidence: (map['confidence'] as num).toDouble(),
    success: map['success'] == 1,
    timestamp: DateTime.fromMillisecondsSinceEpoch(map['timestamp']),
  );
}

class FactModel {
  final int? id;
  final String key; // مثل: name, age, job
  final String value; // مثل: محمد، 25
  final String source; // منين اتعلمها: user_told, learned
  final DateTime timestamp;

  FactModel({this.id, required this.key, required this.value, required this.source, required this.timestamp});

  Map<String, dynamic> toMap() => {
    'id': id,
    'key': key,
    'value': value,
    'source': source,
    'timestamp': timestamp.millisecondsSinceEpoch,
  };

  factory FactModel.fromMap(Map<String, dynamic> map) => FactModel(
    id: map['id'],
    key: map['key'],
    value: map['value'],
    source: map['source'],
    timestamp: DateTime.fromMillisecondsSinceEpoch(map['timestamp']),
  );
}

class WordModel {
  final int? id;
  final String word;
  final int frequency;
  final DateTime firstSeen;
  final DateTime lastSeen;

  WordModel({this.id, required this.word, required this.frequency, required this.firstSeen, required this.lastSeen});

  Map<String, dynamic> toMap() => {
    'id': id,
    'word': word,
    'frequency': frequency,
    'firstSeen': firstSeen.millisecondsSinceEpoch,
    'lastSeen': lastSeen.millisecondsSinceEpoch,
  };

  factory WordModel.fromMap(Map<String, dynamic> map) => WordModel(
    id: map['id'],
    word: map['word'],
    frequency: map['frequency'],
    firstSeen: DateTime.fromMillisecondsSinceEpoch(map['firstSeen']),
    lastSeen: DateTime.fromMillisecondsSinceEpoch(map['lastSeen']),
  );
}

class DecisionLogModel {
  final int? id;
  final String input;
  final String intent;
  final String decision;
  final String reasoning;
  final double confidence;
  final DateTime timestamp;

  DecisionLogModel({this.id, required this.input, required this.intent, required this.decision, required this.reasoning, required this.confidence, required this.timestamp});

  Map<String, dynamic> toMap() => {
    'id': id,
    'input': input,
    'intent': intent,
    'decision': decision,
    'reasoning': reasoning,
    'confidence': confidence,
    'timestamp': timestamp.millisecondsSinceEpoch,
  };
}
