import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'models.dart';

/// قاعدة بيانات حقيقية SQLite - المرحلة 2
/// تخزين: المحادثات، المعلومات، الكلمات الجديدة، سجل القرارات، مستوى التطور
class AppDatabase {
  static final AppDatabase _instance = AppDatabase._internal();
  factory AppDatabase() => _instance;
  AppDatabase._internal();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final path = join(await getDatabasesPath(), 'ai_core_os_v2.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        // جدول المحادثات
        await db.execute('''
          CREATE TABLE conversations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input TEXT NOT NULL,
            output TEXT NOT NULL,
            intent TEXT NOT NULL,
            command TEXT NOT NULL,
            confidence REAL NOT NULL,
            success INTEGER NOT NULL,
            timestamp INTEGER NOT NULL
          )
        ''');

        // جدول الحقائق - الاسم، العمر، أي معلومة
        await db.execute('''
          CREATE TABLE facts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT NOT NULL UNIQUE,
            value TEXT NOT NULL,
            source TEXT NOT NULL,
            timestamp INTEGER NOT NULL
          )
        ''');

        // جدول الكلمات الجديدة
        await db.execute('''
          CREATE TABLE words(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            word TEXT NOT NULL UNIQUE,
            frequency INTEGER NOT NULL,
            firstSeen INTEGER NOT NULL,
            lastSeen INTEGER NOT NULL
          )
        ''');

        // سجل القرارات
        await db.execute('''
          CREATE TABLE decision_logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            input TEXT NOT NULL,
            intent TEXT NOT NULL,
            decision TEXT NOT NULL,
            reasoning TEXT NOT NULL,
            confidence REAL NOT NULL,
            timestamp INTEGER NOT NULL
          )
        ''');

        // جدول التطور
        await db.execute('''
          CREATE TABLE evolution(
            id INTEGER PRIMARY KEY,
            level REAL NOT NULL,
            totalConversations INTEGER NOT NULL,
            totalSuccess INTEGER NOT NULL,
            totalFacts INTEGER NOT NULL,
            totalWords INTEGER NOT NULL,
            lastUpdate INTEGER NOT NULL
          )
        ''');

        // إدخال مستوى ابتدائي
        await db.insert('evolution', {
          'id': 1,
          'level': 50.0,
          'totalConversations': 0,
          'totalSuccess': 0,
          'totalFacts': 0,
          'totalWords': 0,
          'lastUpdate': DateTime.now().millisecondsSinceEpoch,
        });

        // معرفة افتراضية
        await db.insert('facts', {
          'key': 'system_name',
          'value': 'Nawar AI',
          'source': 'system',
          'timestamp': DateTime.now().millisecondsSinceEpoch,
        });
      },
    );
  }

  // ============ Conversations ============
  Future<int> insertConversation(ConversationModel conv) async {
    final db = await database;
    return await db.insert('conversations', conv.toMap());
  }

  Future<List<ConversationModel>> getRecentConversations(int limit) async {
    final db = await database;
    final maps = await db.query('conversations', orderBy: 'timestamp DESC', limit: limit);
    return maps.map((m) => ConversationModel.fromMap(m)).toList();
  }

  Future<List<ConversationModel>> searchConversations(String query) async {
    final db = await database;
    final maps = await db.query('conversations', where: 'input LIKE ? OR output LIKE ?', whereArgs: ['%$query%', '%$query%']);
    return maps.map((m) => ConversationModel.fromMap(m)).toList();
  }

  Future<int> getConversationsCount() async {
    final db = await database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM conversations');
    return result.first['count'] as int;
  }

  // ============ Facts - الاسم، العمر، أي معلومة ============
  Future<void> saveFact(String key, String value, {String source = 'user'}) async {
    final db = await database;
    await db.insert('facts', {
      'key': key.toLowerCase(),
      'value': value,
      'source': source,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<String?> getFact(String key) async {
    final db = await database;
    final maps = await db.query('facts', where: 'key = ?', whereArgs: [key.toLowerCase()]);
    if (maps.isNotEmpty) return maps.first['value'] as String;
    return null;
  }

  Future<List<FactModel>> getAllFacts() async {
    final db = await database;
    final maps = await db.query('facts');
    return maps.map((m) => FactModel.fromMap(m)).toList();
  }

  // ============ Words ============
  Future<void> saveOrUpdateWord(String word) async {
    final db = await database;
    final existing = await db.query('words', where: 'word = ?', whereArgs: [word]);
    if (existing.isEmpty) {
      await db.insert('words', {
        'word': word,
        'frequency': 1,
        'firstSeen': DateTime.now().millisecondsSinceEpoch,
        'lastSeen': DateTime.now().millisecondsSinceEpoch,
      });
    } else {
      final currentFreq = existing.first['frequency'] as int;
      await db.update('words', {
        'frequency': currentFreq + 1,
        'lastSeen': DateTime.now().millisecondsSinceEpoch,
      }, where: 'word = ?', whereArgs: [word]);
    }
  }

  // ============ Evolution ============
  Future<void> updateEvolution({required double level, required int conversations, required int success, required int facts, required int words}) async {
    final db = await database;
    await db.update('evolution', {
      'level': level,
      'totalConversations': conversations,
      'totalSuccess': success,
      'totalFacts': facts,
      'totalWords': words,
      'lastUpdate': DateTime.now().millisecondsSinceEpoch,
    }, where: 'id = ?', whereArgs: [1]);
  }

  Future<Map<String, dynamic>?> getEvolution() async {
    final db = await database;
    final maps = await db.query('evolution', where: 'id = ?', whereArgs: [1]);
    return maps.isNotEmpty ? maps.first : null;
  }

  Future<void> clearAll() async {
    final db = await database;
    await db.delete('conversations');
    await db.delete('facts');
    await db.delete('words');
    await db.delete('decision_logs');
    await db.update('evolution', {
      'level': 50.0,
      'totalConversations': 0,
      'totalSuccess': 0,
      'totalFacts': 0,
      'totalWords': 0,
      'lastUpdate': DateTime.now().millisecondsSinceEpoch,
    }, where: 'id = ?', whereArgs: [1]);
  }
}
