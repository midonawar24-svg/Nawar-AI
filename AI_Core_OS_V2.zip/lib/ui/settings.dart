import 'package:flutter/material.dart';
import '../core/ai_core.dart';
import '../security/pin.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _aiCore = AICore();
  final _pinService = PinService();
  final _pinController = TextEditingController();
  Map<String, dynamic>? _stats;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final s = await _aiCore.getStats();
    if (mounted) setState(() => _stats = s);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إعدادات AI Core OS V2')),
      body: _stats == null ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
        Card(color: Colors.white.withOpacity(0.05), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('حالة العقل', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.cyanAccent)),
          const SizedBox(height: 12),
          Text('التطور: ${_stats!['evolution'].toStringAsFixed(1)}%'),
          Text('الوصف: ${_aiCore.getEvolutionDescription()}'),
          const Divider(),
          Text('المحادثات: ${_stats!['totalConversations']}'),
          Text('الحقائق: ${(_stats!['facts'] as List).length}'),
          Text('آخر محادثات: ${(_stats!['recentConversations'] as List).length}'),
        ]))),
        const SizedBox(height: 16),
        Card(color: Colors.white.withOpacity(0.05), child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
          const Text('تغيير PIN'),
          TextField(controller: _pinController, obscureText: true, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'PIN جديد')),
          const SizedBox(height: 8),
          ElevatedButton(onPressed: () async { await _pinService.savePin(_pinController.text); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم حفظ PIN'))); }, child: const Text('حفظ PIN')),
        ]))),
        const SizedBox(height: 16),
        ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent), onPressed: () async { await _aiCore.clearAll(); await _loadStats(); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم مسح كل شيء - SQLite فاضي'))); }, child: const Text('مسح كل شيء - SQLite')),
        const SizedBox(height: 24),
        const Text('AI Core OS V2\n• SQLite بدل SharedPreferences\n• ذاكرة حقيقية للاسم والعمر وأي معلومة\n• قاعدة معرفة محلية\n• محرك قرارات ذكي\n• تعلم ذاتي\n• 100% أوفلاين - بدون Gemini/OpenAI\n• جاهز لإضافة Gemma/Qwen/Phi محلياً', style: TextStyle(color: Colors.white38, fontSize: 11), textAlign: TextAlign.center),
      ]),
    );
  }
}
