import 'package:flutter/material.dart';
import '../core/ai_core.dart';
import '../database/models.dart';

class MemoryScreen extends StatefulWidget {
  const MemoryScreen({super.key});
  @override
  State<MemoryScreen> createState() => _MemoryScreenState();
}

class _MemoryScreenState extends State<MemoryScreen> {
  final _aiCore = AICore();
  List<FactModel> _facts = [];
  List<ConversationModel> _recent = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final stats = await _aiCore.getStats();
    setState(() {
      _facts = stats['facts'] as List<FactModel>;
      _recent = stats['recentConversations'] as List<ConversationModel>;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ذاكرة نوار - SQLite')),
      body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(12), children: [
        Card(color: Colors.white.withOpacity(0.05), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('الحقائق المحفوظة (الاسم، العمر، أي معلومة)', style: TextStyle(color: Colors.cyanAccent, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ..._facts.map((f) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: Colors.deepPurpleAccent.withOpacity(0.3), borderRadius: BorderRadius.circular(6)), child: Text(f.key, style: const TextStyle(fontSize: 10))), const SizedBox(width: 8), Expanded(child: Text(f.value, style: const TextStyle(fontSize: 12))), Text(f.source, style: const TextStyle(fontSize: 8, color: Colors.white38))]))),
          if (_facts.isEmpty) const Text('لا توجد حقائق بعد - قل "اسمي محمد"', style: TextStyle(color: Colors.white38, fontSize: 11)),
        ]))),
        const SizedBox(height: 12),
        Card(color: Colors.white.withOpacity(0.05), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('آخر المحادثات (SQLite)', style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ..._recent.reversed.map((c) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('أنت: ${c.input}', style: const TextStyle(fontSize: 11, color: Colors.white70)),
            Text('نوار: ${c.output}', style: const TextStyle(fontSize: 11, color: Colors.cyanAccent)),
            Text('${c.intent} • ${(c.confidence * 100).toStringAsFixed(0)}% • ${c.timestamp.hour}:${c.timestamp.minute}', style: const TextStyle(fontSize: 8, color: Colors.white30)),
            const Divider(height: 12, color: Colors.white10),
          ]))),
        ]))),
      ]),
    );
  }
}
