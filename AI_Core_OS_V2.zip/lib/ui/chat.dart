import 'package:flutter/material.dart';
import '../database/models.dart';

class ChatBubble extends StatelessWidget {
  final ConversationModel message;
  final bool isUser;
  const ChatBubble({super.key, required this.message, required this.isUser});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.85),
        decoration: BoxDecoration(
          color: isUser ? Colors.deepPurpleAccent.withOpacity(0.3) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16).copyWith(
            bottomRight: isUser ? const Radius.circular(4) : null,
            bottomLeft: !isUser ? const Radius.circular(4) : null,
          ),
          border: Border.all(color: isUser ? Colors.deepPurpleAccent.withOpacity(0.5) : Colors.white10),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(isUser ? message.input : message.output, style: TextStyle(color: isUser ? Colors.white : Colors.white70, fontSize: 14, height: 1.4)),
          const SizedBox(height: 4),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('${message.timestamp.hour}:${message.timestamp.minute.toString().padLeft(2, '0')}', style: const TextStyle(fontSize: 9, color: Colors.white38)),
            Text('${message.intent.split('.').last} • ${(message.confidence * 100).toStringAsFixed(0)}%', style: const TextStyle(fontSize: 8, color: Colors.white38)),
          ]),
        ]),
      ),
    );
  }
}

class UserInputBubble extends StatelessWidget {
  final String text;
  const UserInputBubble({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerRight,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.deepPurpleAccent.withOpacity(0.3), borderRadius: BorderRadius.circular(16).copyWith(bottomRight: const Radius.circular(4)), border: Border.all(color: Colors.deepPurpleAccent.withOpacity(0.5))),
        child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 14)),
      ),
    );
  }
}
