import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';

class SpeechService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _initialized = false;
  bool _isListening = false;

  bool get isListening => _isListening;

  Future<bool> init() async {
    if (_initialized) return true;
    final status = await Permission.microphone.request();
    if (!status.isGranted) return false;
    _initialized = await _speech.initialize();
    return _initialized;
  }

  Future<void> startListening({required Function(String) onResult}) async {
    if (!await init()) return;
    _isListening = true;
    await _speech.listen(
      localeId: "ar_EG",
      listenFor: const Duration(seconds: 30),
      onResult: (val) => onResult(val.recognizedWords),
    );
  }

  Future<void> stop() async {
    _isListening = false;
    await _speech.stop();
  }

  void dispose() => _speech.stop();
}
