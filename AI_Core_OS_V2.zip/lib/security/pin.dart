import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class PinService {
  String _hash(String pin) => base64Encode(utf8.encode(pin + '_ai_core_os_v2'));

  Future<String> getSavedHash() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('pin_hash_core_v2') ?? _hash('1234');
  }

  Future<void> savePin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('pin_hash_core_v2', _hash(pin));
  }

  Future<bool> verify(String pin) async {
    final saved = await getSavedHash();
    return _hash(pin) == saved;
  }
}
